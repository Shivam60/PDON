import subprocess,sys
#print(sys.argv[1])
command = "ffmpeg -i "+sys.argv[1]+" -ab 160k -ac 2 -ar 44100 -vn "+sys.argv[1].split(".")[0]+".mp3"
#print(command)
subprocess.call(command, shell=True)

